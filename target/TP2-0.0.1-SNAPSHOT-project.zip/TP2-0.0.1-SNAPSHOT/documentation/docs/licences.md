#Licences

Ce projet est distribué sous licence <a href="https://unlicense.org">UNLICENCE.</a>

## Ressources et sources utilisées pour la documentation

### MkDocs

* Débuter avec MkDocs : <a href="https://www.mkdocs.org/#getting-started">source.</a>
* Configuration de la documentation : <a href="https://www.mkdocs.org/user-guide/configuration/">source.</a>

### Maven

* Configuration de la documentation : <a href="http://maven.apache.org/guides/getting-started/index.html#How_do_I_compile_my_application_sources">source.</a>