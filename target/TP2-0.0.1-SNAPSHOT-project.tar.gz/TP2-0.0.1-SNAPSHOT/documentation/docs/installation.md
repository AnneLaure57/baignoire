#Éxécuter l'application 

Pour executer le programme, il faut : 

* Lancer un utilitaire de commandes :
	* Sous Windows : une invite de commandes
	* Sous Linux/Unix/Mac  : un terminal
* À l'aide de la commande *cd*, rendez-vous dans le répertoire où se trouve le *.bat*, ou ouvrez directement l'utilitaire dans le répertoire,
* Executer la commande **app.bat**,
	* la fenêtre de l'application s'ouvrira.

