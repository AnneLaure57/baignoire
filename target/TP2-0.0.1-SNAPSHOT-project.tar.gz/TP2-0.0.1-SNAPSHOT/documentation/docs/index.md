# Accueil

##Nom du projet

TP2 - Application de gestion du volumes d'eau dans une baignoire à l'aide des threads.

##Livrable

* À rendre :
	* une distribution source,
	* une distribution binaire,
	* une documentation complète.

##Description de l'application

Ce projet correspond au TP2 réalisé lors du cours de programation objet avancée en Master 1 MIAGE.

L'application permet à partir de l'interface de :

* Régler le volume initiale de la baignoire,
* Régler le volume d'eau ajouté (qteVerse),
* Régler le vome d'eau retiré (qteFuite).

L'objectif étant de calculé le temps que met une baignoire pour se remplir (le calcul a été fait en secondes).

##Auteur

Anne-Laure CHARLES - M1 MIAGE - Parcours Alternance



